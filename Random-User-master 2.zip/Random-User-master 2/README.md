# Random User
This is an iOS mobile app for the project. This app consists of three screens - Splash Screen, Users list (Table UI View) Screen and User Detailed View Screen.

### Author
Sitharaman Deepak Guptha

### API Link
(https://randomuser.me/api/?results=30&seed=sitharaman)

### Colors
Colors used in this app are,
* Color 1: #EFF7FF
* Color 2: #D7263D
* Color 3: #4E8080
* Color 4: #FF9500